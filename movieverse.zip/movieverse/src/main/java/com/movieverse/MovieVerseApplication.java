package com.movieverse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieVerseApplication {
    public static void main(String[] args) {
        SpringApplication.run(MovieVerseApplication.class, args);
    }
}
